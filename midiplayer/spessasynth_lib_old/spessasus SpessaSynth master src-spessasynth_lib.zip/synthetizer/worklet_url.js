/**
 * The absolute path (from the spessasynth_lib folder) to the worklet module
 * @type {string}
 */
export const WORKLET_URL_ABSOLUTE = "synthetizer/worklet_processor.min.js";