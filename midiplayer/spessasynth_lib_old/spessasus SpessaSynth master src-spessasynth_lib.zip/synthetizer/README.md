## This is the main synthesizer folder.

The code here is responsible for making the actual sound.
This is the heart of the SpessaSynth library.

- `worklet_system` - the current synthesis system with AudioWorklets.

`worklet_processor.min.js` - the minified worklet processor code to import.