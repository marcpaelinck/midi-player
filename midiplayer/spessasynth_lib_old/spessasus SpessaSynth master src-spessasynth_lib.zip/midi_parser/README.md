## This is the MIDI file parsing folder.

The code here is responsible for parsing the MIDI files and interpreting the messsages.
All the events are defined in the `midi_message.js` file.