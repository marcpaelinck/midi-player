## This is the MIDI handling folder.

The code here is respnsible for dealing with MIDI Inputs and outputs
and also for the WebMidiLink functionality.