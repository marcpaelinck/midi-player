## This is the utility folder.

There are various utilites here used by the SpessaSynth library.

### Note that the stbvorbis_sync.js is licensed under Apache-2.0.